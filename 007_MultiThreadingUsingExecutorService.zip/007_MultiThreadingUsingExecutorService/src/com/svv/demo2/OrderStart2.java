package com.svv.demo2;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OrderStart2 {
	
	public static void main(String[] args) {
		
		ExecutorService exeService = Executors.newFixedThreadPool(3);
		
		exeService.submit(()->{OrderStart2.dataInsertTable1();});
		exeService.submit(()->{OrderStart2.dataInsertTable2();});
		exeService.submit(()->{OrderStart2.serialNumberGeneration();});
		exeService.submit(()->{OrderStart2.barcodeGeneration();});
		exeService.submit(()->{OrderStart2.orderStart();});
		
	}
	
	public static void dataInsertTable1()
	{
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Data inserted in table 1" + " (Thread ->"+Thread.currentThread().getName()+")");
	}
	public static void dataInsertTable2()
	{
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Data inserted in table 2" + " (Thread ->"+Thread.currentThread().getName()+")");
	}
	public static void serialNumberGeneration()
	{
		try {
			Thread.sleep(20);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Serialnumber generated" + " (Thread ->"+Thread.currentThread().getName()+")");
	}
	public static void barcodeGeneration()
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Barcode generated" + " (Thread ->"+Thread.currentThread().getName()+")");
	}
	public static void orderStart()
	{
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Order started" + " (Thread ->"+Thread.currentThread().getName()+")");
	}
}
