package com.svv;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OrderStart {

	public static void main(String[] args) {

		OrderStart os = new OrderStart();
		os.doOrderStart();

	}

	public void doOrderStart() {
		System.out.println("Order Started");

		String vin = "1234";

		ExecutorService exeService = Executors.newFixedThreadPool(3);

		exeService.execute(new CreateBuildSheetThread(vin, "10.102.100.1"));
		exeService.execute(new CreateBuildSheetThread(vin, "10.102.100.2"));
		exeService.execute(new CreateBuildSheetThread(vin, "10.102.100.3"));

		System.out.println("Order start process finished");
	}

}

class CreateBuildSheetThread extends Thread {

	private String vin;
	private String ipAddress;

	public CreateBuildSheetThread(String vin, String ipAddress) {
		super();
		this.vin = vin;
		this.ipAddress = ipAddress;
	}

	@Override
	public void run() {

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(Thread.currentThread().getName() + " --- " + "Barcode for vin " + vin
				+ " generated and file send to Printer " + ipAddress);

	}

}
